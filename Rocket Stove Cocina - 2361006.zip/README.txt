Rocket Stove Cocina by fablabbrc on Thingiverse: https://www.thingiverse.com/thing:2361006

Summary:
Cocina a leña para exteriores de consumo optimizado, de bajo costo de producción y simple construcción. 